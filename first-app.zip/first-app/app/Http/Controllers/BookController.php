<?php

namespace App\Http\Controllers;
use App\Http\Requests\CreateBookRequest;
use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\StoreBookRequest;
use App\Http\Requests\Auth\UpdateBookRequest;

class BookController extends Controller
{
    // list 
    public function index()
    {
        $books = Book::orderBy('id', 'desc')->paginate(10);
        $page = "Books";
        return view('books', [
            "page" => $page,
            "books" => $books
        ]);
    }
    // view page of create

    public function create()
    {
        $page = "create book";     
       $categories = Category::all();
        return view('create-book', ['page' => $page, 'categories' => $categories]);
        Book::create([
            "title"=>"nsdaasd",
            "price"=>20,
         
         ]);
    }
    // create
    public function store(CreateBookRequest $request)
    { $fileName = Book::uploadFile($request, $request->pic);
        Book::create([
            "title" => $request->title,
            "price" => $request->price,
            "description" => $request->description,
            "cat_id" => $request->category,
            "pic" => $fileName
        ]);
        return redirect()->route('books.index');
    }
    public function show($book)
     {
         $book = Book::findOrFail($book);
         dd($book);
         // return view();// task 
         Book::all();
Book::find(ID);
/// condition price > 5 
Book::where('price'>5)->get();
     }
    public function edit($id){
        $book = Book::find($id);
  
        return view('books.edit')->with('books',$book);
     }


     public function update(Request $request,$id){
        $data = $request->except('_method','_token','submit');
  
        $validator = Validator::make($request->all(), [
           'id' => 'required|string|min:3',
           'desc' => 'required|string|min:3',
        ]);
  
        if ($validator->fails()) {
           return redirect()->Back()->withInput()->withErrors($validator);
        }
        $book = Book::find($id);
        $book->title="test";
         $book->save();
  
        if($book->update($data)){
  
           Session::flash('message', 'Update successfully!');
           Session::flash('alert-class', 'alert-success');
           return redirect()->route('books');
        }else{
           Session::flash('message', 'Data not updated!');
           Session::flash('alert-class', 'alert-danger');
        }
  
        return Back()->withInput();
     }
  
   
  

    public function destroy($book)
    {
        $book = Book::find($id);
        $book = Book::find($book);
        $book->delete();
        return redirect()->back();
    }
}