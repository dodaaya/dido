<?php

use App\Http\Controllers\BookController;
use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/// method -> http request -> get , post
Route::get('/', function () {
    return view('welcome');
});

// create route /profile
Route::get('/books', function () {
    $books = [
        [
            "title" => 1980,
            "price" => 50
        ],
        [
            "title" => "Laravel",
            "price" => 100
        ],
        [
            "title" => "Vue",
            "price" => 100
        ],
    ];
    $page = "Books";
    return view('books', [
        "page" => $page,
        "books" => $books
    ]); //resource/views/''
Route::middleware(['auth', 'check-age'])->group(function () {
    Route::resource('books', BookController::class, ['except' => ['update', 'edit']]);
});

Route::get('create-book', function () {
    $page = "create book";
    return view('create-book', ['page' => $page]);
});
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
});
Route::group(['middleware' => ['auth'], 'prefix' => 'admin', 'as' => 'admin.'], function () {
    // ... other routes
    Route::resource('books', 'Admin\BookController');
});