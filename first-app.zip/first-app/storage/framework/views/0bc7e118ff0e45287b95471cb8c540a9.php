
<?php $__env->startSection('content'); ?>
    <h1><?php echo e($page); ?></h1>
    <?php if(isset($books)): ?>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Price</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($index); ?></th>
                        <td><?php echo e($book['title']); ?></td>
                        <td><?php echo e($book['price']); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    <?php else: ?>
        <p> No Books</p>
        <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('book-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dtare\first-app\resources\views/books.blade.php ENDPATH**/ ?>